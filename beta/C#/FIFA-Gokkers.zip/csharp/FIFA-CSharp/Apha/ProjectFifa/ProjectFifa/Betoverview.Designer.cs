﻿namespace ProjectFifa
{
    partial class Betoverview
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.poolButton = new System.Windows.Forms.Button();
            this.selectPouleDomain = new System.Windows.Forms.DomainUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.betOverviewToFormButton = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aanmakenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gokkerAanmakenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.overviewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.betOverviewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.teamOverviewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aanmakenToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.gokkerAanmakenToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.weddenschapAanmakenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(180, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 16);
            this.label3.TabIndex = 22;
            this.label3.Text = "Poule";
            // 
            // poolButton
            // 
            this.poolButton.BackColor = System.Drawing.Color.White;
            this.poolButton.Location = new System.Drawing.Point(249, 84);
            this.poolButton.Name = "poolButton";
            this.poolButton.Size = new System.Drawing.Size(55, 23);
            this.poolButton.TabIndex = 21;
            this.poolButton.Text = "Go";
            this.poolButton.UseVisualStyleBackColor = false;
            // 
            // selectPouleDomain
            // 
            this.selectPouleDomain.BackColor = System.Drawing.Color.White;
            this.selectPouleDomain.Location = new System.Drawing.Point(183, 87);
            this.selectPouleDomain.Name = "selectPouleDomain";
            this.selectPouleDomain.Size = new System.Drawing.Size(60, 20);
            this.selectPouleDomain.TabIndex = 20;
            this.selectPouleDomain.Text = "domainUpDown1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(12, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 20);
            this.label1.TabIndex = 23;
            this.label1.Text = "Gok Overzicht";
            // 
            // listBox1
            // 
            this.listBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(16, 110);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(288, 251);
            this.listBox1.TabIndex = 24;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(16, 81);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(83, 23);
            this.button1.TabIndex = 25;
            this.button1.Text = "Gok op match";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // betOverviewToFormButton
            // 
            this.betOverviewToFormButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.betOverviewToFormButton.Location = new System.Drawing.Point(16, 380);
            this.betOverviewToFormButton.Name = "betOverviewToFormButton";
            this.betOverviewToFormButton.Size = new System.Drawing.Size(75, 23);
            this.betOverviewToFormButton.TabIndex = 26;
            this.betOverviewToFormButton.Text = "Back";
            this.betOverviewToFormButton.UseVisualStyleBackColor = true;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.aanmakenToolStripMenuItem,
            this.overviewToolStripMenuItem,
            this.aanmakenToolStripMenuItem1,
            this.exitToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(320, 24);
            this.menuStrip1.TabIndex = 27;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveToolStripMenuItem,
            this.loadToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.saveToolStripMenuItem.Text = "Save";
            // 
            // loadToolStripMenuItem
            // 
            this.loadToolStripMenuItem.Name = "loadToolStripMenuItem";
            this.loadToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.loadToolStripMenuItem.Text = "Load";
            // 
            // aanmakenToolStripMenuItem
            // 
            this.aanmakenToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gokkerAanmakenToolStripMenuItem});
            this.aanmakenToolStripMenuItem.Name = "aanmakenToolStripMenuItem";
            this.aanmakenToolStripMenuItem.Size = new System.Drawing.Size(76, 20);
            this.aanmakenToolStripMenuItem.Text = "Aanmaken";
            // 
            // gokkerAanmakenToolStripMenuItem
            // 
            this.gokkerAanmakenToolStripMenuItem.Name = "gokkerAanmakenToolStripMenuItem";
            this.gokkerAanmakenToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.gokkerAanmakenToolStripMenuItem.Text = "Gokker Aanmaken";
            // 
            // overviewToolStripMenuItem
            // 
            this.overviewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.betOverviewToolStripMenuItem,
            this.teamOverviewToolStripMenuItem});
            this.overviewToolStripMenuItem.Name = "overviewToolStripMenuItem";
            this.overviewToolStripMenuItem.Size = new System.Drawing.Size(82, 20);
            this.overviewToolStripMenuItem.Text = "Overzichten";
            // 
            // betOverviewToolStripMenuItem
            // 
            this.betOverviewToolStripMenuItem.Name = "betOverviewToolStripMenuItem";
            this.betOverviewToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.betOverviewToolStripMenuItem.Text = "Gok Overzicht";
            // 
            // teamOverviewToolStripMenuItem
            // 
            this.teamOverviewToolStripMenuItem.Name = "teamOverviewToolStripMenuItem";
            this.teamOverviewToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.teamOverviewToolStripMenuItem.Text = "Team Overzicht";
            // 
            // aanmakenToolStripMenuItem1
            // 
            this.aanmakenToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gokkerAanmakenToolStripMenuItem1,
            this.weddenschapAanmakenToolStripMenuItem});
            this.aanmakenToolStripMenuItem1.Name = "aanmakenToolStripMenuItem1";
            this.aanmakenToolStripMenuItem1.Size = new System.Drawing.Size(76, 20);
            this.aanmakenToolStripMenuItem1.Text = "Aanmaken";
            // 
            // gokkerAanmakenToolStripMenuItem1
            // 
            this.gokkerAanmakenToolStripMenuItem1.Name = "gokkerAanmakenToolStripMenuItem1";
            this.gokkerAanmakenToolStripMenuItem1.Size = new System.Drawing.Size(209, 22);
            this.gokkerAanmakenToolStripMenuItem1.Text = "Gokker Aanmaken";
            // 
            // weddenschapAanmakenToolStripMenuItem
            // 
            this.weddenschapAanmakenToolStripMenuItem.Name = "weddenschapAanmakenToolStripMenuItem";
            this.weddenschapAanmakenToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.weddenschapAanmakenToolStripMenuItem.Text = "Weddenschap Aanmaken";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // Betoverview
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(320, 410);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.betOverviewToFormButton);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.poolButton);
            this.Controls.Add(this.selectPouleDomain);
            this.Name = "Betoverview";
            this.Text = "Gokoverzicht";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button poolButton;
        private System.Windows.Forms.DomainUpDown selectPouleDomain;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button betOverviewToFormButton;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aanmakenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gokkerAanmakenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem overviewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem betOverviewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem teamOverviewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aanmakenToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem gokkerAanmakenToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem weddenschapAanmakenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
    }
}