﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectFifa
{
    class gokkerStorage
    {
        public const string LOCATION = "./gokkers/";
        public List<gokker> gokkers { get; set; }

        /*public betStorage()
        {
            this.bets = this.Load();
        }*/
        public void save()
        {
            if (!Directory.Exists(LOCATION))
            {
                Directory.CreateDirectory(LOCATION);
            }

            foreach (string filename in Directory.EnumerateFiles(LOCATION))
            {
                File.Delete(filename);
            }
            foreach (gokker gokkersave in this.gokkers)
            {
                string fileContent = "";

                fileContent += gokkersave.name;

                fileContent += "\n" + gokkersave.balance;

                fileContent += "\n" + gokkersave.mybets;

                string safeTitle = RemoveInvalidFileNameChars(gokkersave.name);

                File.WriteAllText(LOCATION + safeTitle, fileContent);
            }
        }

        public List<gokker> Load()  //Bron: Docent tim: File: UsingObjects// :) Natuurlijk aan gepast naar mijn wensen
        {
            List<gokker> result = new List<gokker>();

            if (!Directory.Exists(LOCATION))
            {

                return result;
            }
            foreach (string fileName in Directory.EnumerateFiles(LOCATION))
            {
                string fileContent = File.ReadAllText(fileName);

                gokker loadedGokker = new gokker();

                string[] contentLines = fileContent.Split('\n');

                loadedGokker.name = contentLines[0];

                loadedGokker.balance = contentLines[1];

                result.Add(loadedGokker);
            }
            return result;
        }

        private string RemoveInvalidFileNameChars(string title)
        {
            string fileName = title;

            // Bron: https://stackoverflow.com/questions/333175/is-there-a-way-of-making-strings-file-path-safe-in-c
            foreach (var invalidChar in Path.GetInvalidFileNameChars())
            {
                fileName = fileName.Replace(invalidChar, '-');
            }

            return fileName;
        }
        // niet vergeten.
        public void addCar(gokker newcar)
        {
            this.gokkers.Add(newcar);
        }
    }
}
