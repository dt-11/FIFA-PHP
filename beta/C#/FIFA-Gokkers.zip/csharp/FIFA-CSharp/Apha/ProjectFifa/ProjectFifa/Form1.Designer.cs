﻿namespace ProjectFifa
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.poolButton = new System.Windows.Forms.Button();
            this.selectPouleDomain = new System.Windows.Forms.DomainUpDown();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.matchLabel8 = new System.Windows.Forms.Label();
            this.matchLabel7 = new System.Windows.Forms.Label();
            this.matchLabel4 = new System.Windows.Forms.Label();
            this.matchLabel5 = new System.Windows.Forms.Label();
            this.matchLabel6 = new System.Windows.Forms.Label();
            this.matchLabel3 = new System.Windows.Forms.Label();
            this.matchLabel2 = new System.Windows.Forms.Label();
            this.selectedPoolLabel = new System.Windows.Forms.Label();
            this.matchLabel1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.matchLabel13 = new System.Windows.Forms.Label();
            this.matchLabel14 = new System.Windows.Forms.Label();
            this.matchLabel15 = new System.Windows.Forms.Label();
            this.matchLabel10 = new System.Windows.Forms.Label();
            this.matchLabel11 = new System.Windows.Forms.Label();
            this.matchLabel12 = new System.Windows.Forms.Label();
            this.matchLabel9 = new System.Windows.Forms.Label();
            this.teamOverviewButton = new System.Windows.Forms.Button();
            this.formToBetOverview = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aanmakenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gokkerAanmakenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(311, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 16);
            this.label3.TabIndex = 19;
            this.label3.Text = "Poule";
            // 
            // poolButton
            // 
            this.poolButton.BackColor = System.Drawing.Color.White;
            this.poolButton.Location = new System.Drawing.Point(457, 59);
            this.poolButton.Name = "poolButton";
            this.poolButton.Size = new System.Drawing.Size(55, 23);
            this.poolButton.TabIndex = 17;
            this.poolButton.Text = "Go";
            this.poolButton.UseVisualStyleBackColor = false;
            // 
            // selectPouleDomain
            // 
            this.selectPouleDomain.BackColor = System.Drawing.Color.White;
            this.selectPouleDomain.Location = new System.Drawing.Point(314, 59);
            this.selectPouleDomain.Name = "selectPouleDomain";
            this.selectPouleDomain.Size = new System.Drawing.Size(137, 20);
            this.selectPouleDomain.TabIndex = 16;
            this.selectPouleDomain.Text = "domainUpDown1";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.matchLabel8);
            this.groupBox1.Controls.Add(this.matchLabel7);
            this.groupBox1.Controls.Add(this.matchLabel4);
            this.groupBox1.Controls.Add(this.matchLabel5);
            this.groupBox1.Controls.Add(this.matchLabel6);
            this.groupBox1.Controls.Add(this.matchLabel3);
            this.groupBox1.Controls.Add(this.matchLabel2);
            this.groupBox1.Controls.Add(this.selectedPoolLabel);
            this.groupBox1.Controls.Add(this.matchLabel1);
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            this.groupBox1.Location = new System.Drawing.Point(7, 88);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(243, 395);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            // 
            // matchLabel8
            // 
            this.matchLabel8.AutoSize = true;
            this.matchLabel8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.matchLabel8.Location = new System.Drawing.Point(6, 369);
            this.matchLabel8.Name = "matchLabel8";
            this.matchLabel8.Size = new System.Drawing.Size(57, 18);
            this.matchLabel8.TabIndex = 22;
            this.matchLabel8.Text = "Match1";
            // 
            // matchLabel7
            // 
            this.matchLabel7.AutoSize = true;
            this.matchLabel7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.matchLabel7.Location = new System.Drawing.Point(6, 327);
            this.matchLabel7.Name = "matchLabel7";
            this.matchLabel7.Size = new System.Drawing.Size(57, 18);
            this.matchLabel7.TabIndex = 21;
            this.matchLabel7.Text = "Match1";
            // 
            // matchLabel4
            // 
            this.matchLabel4.AutoSize = true;
            this.matchLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.matchLabel4.Location = new System.Drawing.Point(6, 186);
            this.matchLabel4.Name = "matchLabel4";
            this.matchLabel4.Size = new System.Drawing.Size(57, 18);
            this.matchLabel4.TabIndex = 20;
            this.matchLabel4.Text = "Match1";
            // 
            // matchLabel5
            // 
            this.matchLabel5.AutoSize = true;
            this.matchLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.matchLabel5.Location = new System.Drawing.Point(6, 231);
            this.matchLabel5.Name = "matchLabel5";
            this.matchLabel5.Size = new System.Drawing.Size(57, 18);
            this.matchLabel5.TabIndex = 19;
            this.matchLabel5.Text = "Match1";
            // 
            // matchLabel6
            // 
            this.matchLabel6.AutoSize = true;
            this.matchLabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.matchLabel6.Location = new System.Drawing.Point(6, 280);
            this.matchLabel6.Name = "matchLabel6";
            this.matchLabel6.Size = new System.Drawing.Size(57, 18);
            this.matchLabel6.TabIndex = 18;
            this.matchLabel6.Text = "Match1";
            // 
            // matchLabel3
            // 
            this.matchLabel3.AutoSize = true;
            this.matchLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.matchLabel3.Location = new System.Drawing.Point(6, 139);
            this.matchLabel3.Name = "matchLabel3";
            this.matchLabel3.Size = new System.Drawing.Size(57, 18);
            this.matchLabel3.TabIndex = 17;
            this.matchLabel3.Text = "Match1";
            // 
            // matchLabel2
            // 
            this.matchLabel2.AutoSize = true;
            this.matchLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.matchLabel2.Location = new System.Drawing.Point(6, 90);
            this.matchLabel2.Name = "matchLabel2";
            this.matchLabel2.Size = new System.Drawing.Size(57, 18);
            this.matchLabel2.TabIndex = 16;
            this.matchLabel2.Text = "Match1";
            // 
            // selectedPoolLabel
            // 
            this.selectedPoolLabel.AutoSize = true;
            this.selectedPoolLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold);
            this.selectedPoolLabel.Location = new System.Drawing.Point(5, 10);
            this.selectedPoolLabel.Name = "selectedPoolLabel";
            this.selectedPoolLabel.Size = new System.Drawing.Size(80, 20);
            this.selectedPoolLabel.TabIndex = 15;
            this.selectedPoolLabel.Text = "Matches";
            // 
            // matchLabel1
            // 
            this.matchLabel1.AutoSize = true;
            this.matchLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.matchLabel1.Location = new System.Drawing.Point(6, 45);
            this.matchLabel1.Name = "matchLabel1";
            this.matchLabel1.Size = new System.Drawing.Size(57, 18);
            this.matchLabel1.TabIndex = 3;
            this.matchLabel1.Text = "Match1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(29, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 26);
            this.label1.TabIndex = 14;
            this.label1.Text = "FIFA";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(7, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 20);
            this.label2.TabIndex = 6;
            this.label2.Text = "Matches";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.matchLabel13);
            this.groupBox2.Controls.Add(this.matchLabel14);
            this.groupBox2.Controls.Add(this.matchLabel15);
            this.groupBox2.Controls.Add(this.matchLabel10);
            this.groupBox2.Controls.Add(this.matchLabel11);
            this.groupBox2.Controls.Add(this.matchLabel12);
            this.groupBox2.Controls.Add(this.matchLabel9);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Cursor = System.Windows.Forms.Cursors.Default;
            this.groupBox2.Location = new System.Drawing.Point(269, 88);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(243, 389);
            this.groupBox2.TabIndex = 18;
            this.groupBox2.TabStop = false;
            // 
            // matchLabel13
            // 
            this.matchLabel13.AutoSize = true;
            this.matchLabel13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.matchLabel13.Location = new System.Drawing.Point(10, 231);
            this.matchLabel13.Name = "matchLabel13";
            this.matchLabel13.Size = new System.Drawing.Size(57, 18);
            this.matchLabel13.TabIndex = 36;
            this.matchLabel13.Text = "Match1";
            // 
            // matchLabel14
            // 
            this.matchLabel14.AutoSize = true;
            this.matchLabel14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.matchLabel14.Location = new System.Drawing.Point(10, 280);
            this.matchLabel14.Name = "matchLabel14";
            this.matchLabel14.Size = new System.Drawing.Size(57, 18);
            this.matchLabel14.TabIndex = 35;
            this.matchLabel14.Text = "Match1";
            // 
            // matchLabel15
            // 
            this.matchLabel15.AutoSize = true;
            this.matchLabel15.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.matchLabel15.Location = new System.Drawing.Point(7, 327);
            this.matchLabel15.Name = "matchLabel15";
            this.matchLabel15.Size = new System.Drawing.Size(57, 18);
            this.matchLabel15.TabIndex = 34;
            this.matchLabel15.Text = "Match1";
            // 
            // matchLabel10
            // 
            this.matchLabel10.AutoSize = true;
            this.matchLabel10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.matchLabel10.Location = new System.Drawing.Point(10, 90);
            this.matchLabel10.Name = "matchLabel10";
            this.matchLabel10.Size = new System.Drawing.Size(57, 18);
            this.matchLabel10.TabIndex = 33;
            this.matchLabel10.Text = "Match1";
            // 
            // matchLabel11
            // 
            this.matchLabel11.AutoSize = true;
            this.matchLabel11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.matchLabel11.Location = new System.Drawing.Point(10, 139);
            this.matchLabel11.Name = "matchLabel11";
            this.matchLabel11.Size = new System.Drawing.Size(57, 18);
            this.matchLabel11.TabIndex = 32;
            this.matchLabel11.Text = "Match1";
            // 
            // matchLabel12
            // 
            this.matchLabel12.AutoSize = true;
            this.matchLabel12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.matchLabel12.Location = new System.Drawing.Point(7, 186);
            this.matchLabel12.Name = "matchLabel12";
            this.matchLabel12.Size = new System.Drawing.Size(57, 18);
            this.matchLabel12.TabIndex = 31;
            this.matchLabel12.Text = "Match1";
            // 
            // matchLabel9
            // 
            this.matchLabel9.AutoSize = true;
            this.matchLabel9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.matchLabel9.Location = new System.Drawing.Point(10, 45);
            this.matchLabel9.Name = "matchLabel9";
            this.matchLabel9.Size = new System.Drawing.Size(57, 18);
            this.matchLabel9.TabIndex = 30;
            this.matchLabel9.Text = "Match1";
            // 
            // teamOverviewButton
            // 
            this.teamOverviewButton.BackColor = System.Drawing.Color.White;
            this.teamOverviewButton.Location = new System.Drawing.Point(7, 59);
            this.teamOverviewButton.Name = "teamOverviewButton";
            this.teamOverviewButton.Size = new System.Drawing.Size(92, 23);
            this.teamOverviewButton.TabIndex = 20;
            this.teamOverviewButton.Text = "Team Overzicht";
            this.teamOverviewButton.UseVisualStyleBackColor = false;
            this.teamOverviewButton.Click += new System.EventHandler(this.overviewButton_Click);
            // 
            // formToBetOverview
            // 
            this.formToBetOverview.BackColor = System.Drawing.Color.White;
            this.formToBetOverview.Location = new System.Drawing.Point(105, 59);
            this.formToBetOverview.Name = "formToBetOverview";
            this.formToBetOverview.Size = new System.Drawing.Size(85, 23);
            this.formToBetOverview.TabIndex = 21;
            this.formToBetOverview.Text = "Gok Overzicht";
            this.formToBetOverview.UseVisualStyleBackColor = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.aanmakenToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(522, 24);
            this.menuStrip1.TabIndex = 23;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveToolStripMenuItem,
            this.loadToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // aanmakenToolStripMenuItem
            // 
            this.aanmakenToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gokkerAanmakenToolStripMenuItem});
            this.aanmakenToolStripMenuItem.Name = "aanmakenToolStripMenuItem";
            this.aanmakenToolStripMenuItem.Size = new System.Drawing.Size(76, 20);
            this.aanmakenToolStripMenuItem.Text = "Aanmaken";
            // 
            // gokkerAanmakenToolStripMenuItem
            // 
            this.gokkerAanmakenToolStripMenuItem.Name = "gokkerAanmakenToolStripMenuItem";
            this.gokkerAanmakenToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.gokkerAanmakenToolStripMenuItem.Text = "Gokker Aanmaken";
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.saveToolStripMenuItem.Text = "Save";
            // 
            // loadToolStripMenuItem
            // 
            this.loadToolStripMenuItem.Name = "loadToolStripMenuItem";
            this.loadToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.loadToolStripMenuItem.Text = "Load";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(522, 484);
            this.Controls.Add(this.formToBetOverview);
            this.Controls.Add(this.teamOverviewButton);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.poolButton);
            this.Controls.Add(this.selectPouleDomain);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button poolButton;
        private System.Windows.Forms.DomainUpDown selectPouleDomain;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label matchLabel4;
        private System.Windows.Forms.Label matchLabel5;
        private System.Windows.Forms.Label matchLabel6;
        private System.Windows.Forms.Label matchLabel3;
        private System.Windows.Forms.Label matchLabel2;
        private System.Windows.Forms.Label selectedPoolLabel;
        private System.Windows.Forms.Label matchLabel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label matchLabel8;
        private System.Windows.Forms.Label matchLabel7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button teamOverviewButton;
        private System.Windows.Forms.Label matchLabel13;
        private System.Windows.Forms.Label matchLabel14;
        private System.Windows.Forms.Label matchLabel15;
        private System.Windows.Forms.Label matchLabel10;
        private System.Windows.Forms.Label matchLabel11;
        private System.Windows.Forms.Label matchLabel12;
        private System.Windows.Forms.Label matchLabel9;
        private System.Windows.Forms.Button formToBetOverview;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aanmakenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gokkerAanmakenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
    }
}

