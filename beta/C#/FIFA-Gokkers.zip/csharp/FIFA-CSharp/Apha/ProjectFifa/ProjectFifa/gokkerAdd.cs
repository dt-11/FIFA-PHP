﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectFifa
{
    public partial class gokkerAdd : Form
    {
        private gokkerStorage storage;

        public gokkerAdd()
        {
            InitializeComponent();
            this.storage = new gokkerStorage();

        }

        private void gokkerAddButton_Click(object sender, EventArgs e)
        {
            string gokkername;
            gokkername = gokkerAddButton.Text;
            //gokker[] gokkers = new gokker[];
            
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            gokkerStorage
        }
    }
}
