﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectFifa
{
    public class bet
    {
        public string WinningTeam { get; set; }
        public string EndScore { get; set; }
        public gokker bettor { get; set; }
        public int pool { get; set; }

    }
}
