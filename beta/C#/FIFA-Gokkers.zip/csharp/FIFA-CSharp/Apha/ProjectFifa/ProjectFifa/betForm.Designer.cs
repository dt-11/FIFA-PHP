﻿namespace ProjectFifa
{
    partial class betForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.betButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.betScoreAmount = new System.Windows.Forms.Label();
            this.teamBetLabel = new System.Windows.Forms.Label();
            this.teamBetDomain = new System.Windows.Forms.DomainUpDown();
            this.betScoreTextBox = new System.Windows.Forms.TextBox();
            this.betsOn = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.domainUpDown1 = new System.Windows.Forms.DomainUpDown();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aanmakenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gokkerAanmakenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.domainUpDown1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.betButton);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.betScoreAmount);
            this.groupBox1.Controls.Add(this.teamBetLabel);
            this.groupBox1.Controls.Add(this.teamBetDomain);
            this.groupBox1.Controls.Add(this.betScoreTextBox);
            this.groupBox1.Controls.Add(this.betsOn);
            this.groupBox1.Location = new System.Drawing.Point(12, 61);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(244, 212);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            // 
            // betButton
            // 
            this.betButton.Location = new System.Drawing.Point(7, 178);
            this.betButton.Name = "betButton";
            this.betButton.Size = new System.Drawing.Size(75, 23);
            this.betButton.TabIndex = 9;
            this.betButton.Text = "Enter";
            this.betButton.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 106);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(193, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Wat is de eindscoren van de wedstrijd?";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Gok wie er wint.";
            // 
            // betScoreAmount
            // 
            this.betScoreAmount.AutoSize = true;
            this.betScoreAmount.Location = new System.Drawing.Point(7, 134);
            this.betScoreAmount.Name = "betScoreAmount";
            this.betScoreAmount.Size = new System.Drawing.Size(85, 13);
            this.betScoreAmount.TabIndex = 6;
            this.betScoreAmount.Text = "Gok eindscoren:";
            // 
            // teamBetLabel
            // 
            this.teamBetLabel.AutoSize = true;
            this.teamBetLabel.Location = new System.Drawing.Point(8, 68);
            this.teamBetLabel.Name = "teamBetLabel";
            this.teamBetLabel.Size = new System.Drawing.Size(37, 13);
            this.teamBetLabel.TabIndex = 5;
            this.teamBetLabel.Text = "Team:";
            // 
            // teamBetDomain
            // 
            this.teamBetDomain.Location = new System.Drawing.Point(52, 66);
            this.teamBetDomain.Name = "teamBetDomain";
            this.teamBetDomain.Size = new System.Drawing.Size(162, 20);
            this.teamBetDomain.TabIndex = 4;
            this.teamBetDomain.Text = "domainUpDown1";
            // 
            // betScoreTextBox
            // 
            this.betScoreTextBox.Location = new System.Drawing.Point(99, 131);
            this.betScoreTextBox.Name = "betScoreTextBox";
            this.betScoreTextBox.Size = new System.Drawing.Size(100, 20);
            this.betScoreTextBox.TabIndex = 3;
            // 
            // betsOn
            // 
            this.betsOn.AutoSize = true;
            this.betsOn.Location = new System.Drawing.Point(7, 16);
            this.betsOn.Name = "betsOn";
            this.betsOn.Size = new System.Drawing.Size(57, 13);
            this.betsOn.TabIndex = 1;
            this.betsOn.Text = "U gokt op:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(12, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 24);
            this.label1.TabIndex = 8;
            this.label1.Text = "Gokken";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(120, 154);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Bijv: 4-1";
            // 
            // domainUpDown1
            // 
            this.domainUpDown1.Location = new System.Drawing.Point(70, 14);
            this.domainUpDown1.Name = "domainUpDown1";
            this.domainUpDown1.Size = new System.Drawing.Size(144, 20);
            this.domainUpDown1.TabIndex = 11;
            this.domainUpDown1.Text = "domainUpDown1";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.aanmakenToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(265, 24);
            this.menuStrip1.TabIndex = 24;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveToolStripMenuItem,
            this.loadToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.saveToolStripMenuItem.Text = "Save";
            // 
            // loadToolStripMenuItem
            // 
            this.loadToolStripMenuItem.Name = "loadToolStripMenuItem";
            this.loadToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.loadToolStripMenuItem.Text = "Load";
            // 
            // aanmakenToolStripMenuItem
            // 
            this.aanmakenToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gokkerAanmakenToolStripMenuItem});
            this.aanmakenToolStripMenuItem.Name = "aanmakenToolStripMenuItem";
            this.aanmakenToolStripMenuItem.Size = new System.Drawing.Size(76, 20);
            this.aanmakenToolStripMenuItem.Text = "Aanmaken";
            // 
            // gokkerAanmakenToolStripMenuItem
            // 
            this.gokkerAanmakenToolStripMenuItem.Name = "gokkerAanmakenToolStripMenuItem";
            this.gokkerAanmakenToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.gokkerAanmakenToolStripMenuItem.Text = "Gokker Aanmaken";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // betForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(265, 284);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Name = "betForm";
            this.Text = "betForm";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button betButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label betScoreAmount;
        private System.Windows.Forms.Label teamBetLabel;
        private System.Windows.Forms.DomainUpDown teamBetDomain;
        private System.Windows.Forms.TextBox betScoreTextBox;
        private System.Windows.Forms.Label betsOn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DomainUpDown domainUpDown1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aanmakenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gokkerAanmakenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
    }
}