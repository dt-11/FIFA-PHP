﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectFifa
{
    public class gokker
    {
        public string name { get; set; }

        public string balance { get; set; }

        public bet mybets { get; set; }

    }
}
